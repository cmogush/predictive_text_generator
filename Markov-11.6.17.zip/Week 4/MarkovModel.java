//2017 Christopher Mogush
//MarkovTwo

import java.util.Random;
import java.util.ArrayList;

public class MarkovModel {
    private String myText;
    private Random myRandom;
    
    public MarkovModel() {
        myRandom = new Random();
    }
    
    public void setRandom(int seed){ //Using this method will allow you to generate the same random text each time
        myRandom = new Random(seed);
    }
    
    public void setTraining(String s){ //The String s is used to initialize the training text
        myText = s.trim(); //method eliminates leading and trailing spaces
    }
    
    public String getRandomText(int numChars, int n){ //generates and returns random text that is numChars long
       //It should predict the next character, by finding all the characters that follow the current character in the training text
       //then randomly picking one of them as the next character.
       if (myText == null){
            return "";
       }
       StringBuilder sb = new StringBuilder();
       int index = myRandom.nextInt(myText.length()-n); //first index is random
       String key = myText.substring(index, index + n); //set starter key to index
       sb.append(key);
       for(int k=0; k < numChars - n; k++){ //n chars already generated, so -n
            ArrayList<String> charsThatFollow = getFollows(key); //key is the current char (previous char that was predicted)
            if(charsThatFollow.size() == 0){break;}
            index = myRandom.nextInt(charsThatFollow.size());
            String next = charsThatFollow.get(index);
            sb.append(next); 
            key = key.substring(1) + next; //set key to current char
       }
        
       return sb.toString();
    }
    
    public ArrayList<String> getFollows(String key){ //key is a single char
        //find all the characters from the private variable myText in MarkovOne that follow key
        //put all these characters into an ArrayList and then return this ArrayList
        ArrayList<String> follows = new ArrayList<String>();
        //iterate over myText
        int pos = 0;
        for(int k=0; k < myText.length() - 1; k++){
           //find match using k as start index
           int index = myText.indexOf(key, pos);
           if(index < myText.length() - key.length() && index != -1){
               String s = myText.substring(index + key.length(), index + key.length() + 1);
               follows.add(s);
               pos = index + 1;
           }
           if(index == -1){break;}
           //System.out.println("Key: " + key + " index " + index + " " + follows);
        }
        return follows;
    }
}

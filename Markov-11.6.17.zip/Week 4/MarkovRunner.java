//2017 Christopher Mogush
//MarkovRunner

import edu.duke.*;
import java.util.*;

public class MarkovRunner {
    public void runMarkovModel() { //generates three sets of randomly generated text using the file read in to choose the random characters from
        int seed;
        System.out.println("Set seed: ");
        Scanner s = new Scanner(System.in);
        seed = s.nextInt();
        System.out.println("Set Markov number: ");
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        FileResource fr = new FileResource();
        String st = fr.asString();
        st = st.replace('\n', ' '); //replaces all new lines with spaces
        //st = "this is a test yes this is a test.";
        MarkovModel markov = new MarkovModel();
        markov.setTraining(st); //sets the training text to the st file
        markov.setRandom(seed);
        for(int k=0; k < 3; k++){
            String text = markov.getRandomText(500, n);
            printOut(text);
        }
    }
    public void runMarkovFour() { //generates three sets of randomly generated text using the file read in to choose the random characters from
        FileResource fr = new FileResource();
        String st = fr.asString();
        st = st.replace('\n', ' '); //replaces all new lines with spaces
        //st = "this is a test yes this is a test.";
        MarkovFour markov = new MarkovFour();
        markov.setTraining(st); //sets the training text to the st file
        markov.setRandom(371);
        for(int k=0; k < 3; k++){
            String text = markov.getRandomText(500);
            printOut(text);
        }
    }
    public void runMarkovTwo() { //generates three sets of randomly generated text using the file read in to choose the random characters from
        FileResource fr = new FileResource();
        String st = fr.asString();
        st = st.replace('\n', ' '); //replaces all new lines with spaces
        //st = "this is a test yes this is a test.";
        MarkovTwo markov = new MarkovTwo();
        markov.setTraining(st); //sets the training text to the st file
        markov.setRandom(42);
        for(int k=0; k < 3; k++){
            String text = markov.getRandomText(500);
            printOut(text);
        }
    }
    public void runMarkovOne() { //generates three sets of randomly generated text using the file read in to choose the random characters from
        FileResource fr = new FileResource();
        String st = fr.asString();
        st = st.replace('\n', ' '); //replaces all new lines with spaces
        //st = "this is a test yes this is a test.";
        MarkovOne markov = new MarkovOne();
        markov.setTraining(st); //sets the training text to the st file
        markov.setRandom(273);
        for(int k=0; k < 3; k++){
            String text = markov.getRandomText(500);
            printOut(text);
        }
    }
    public void runMarkovZero() { //generates three sets of randomly generated text using the file read in to choose the random characters from
        FileResource fr = new FileResource();
        String st = fr.asString();
        st = st.replace('\n', ' '); //replaces all new lines with spaces
        MarkovZero markov = new MarkovZero();
        markov.setRandom(88);
        markov.setTraining(st); //sets the training text to the st file
        for(int k=0; k < 3; k++){
            String text = markov.getRandomText(500);
            printOut(text);
        }
    }
    
    private void printOut(String s){
    //print out the random text that was generated with around 60 characters per line. 
    //DO NOT CHANGE THIS METHOD
        String[] words = s.split("\\s+");
		int psize = 0;
		System.out.println("----------------------------------");
		for(int k=0; k < words.length; k++){
			System.out.print(words[k]+ " ");
			psize += words[k].length() + 1;
			if (psize > 60) {
				System.out.println();
				psize = 0;
			}
		}
		System.out.println("\n----------------------------------");
	}
	
}

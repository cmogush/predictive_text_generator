//2017 Christopher Mogush
//IMarkovModel Interface

public interface IMarkovModel {
    public void setTraining(String text); //sets the training text to the st file
    public String getRandomText(int numChars);
}
